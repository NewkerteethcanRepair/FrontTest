// components/movieItem/movieItem.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    item: {
      type: Object,
      value: {
        movieImg: '/assets/images/movies/p1.jpg',
        title: '复仇者联盟',
        average: '9.0',
        stars: '35'
      }
    }
  },

  /**
   * 组件的初始数据
   */
  data: {

  },

  /**
   * 组件的方法列表
   */
  methods: {
    toDetail(e) {
      // console.log(e.currentTarget.dataset.id);
      wx.navigateTo({
        url: '/pages/detail/detail?_id=' + this.properties.item._id
      })
      wx.setStorage({
        key: 'movie',
        data: this.properties.item
      })

    }
  }
})
