import 'package:douban_app/http/http_methods.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:dio/dio.dart';
import 'dart:async';

import 'package:douban_app/routers/application.dart';
import 'package:douban_app/widgets/movie_item.dart';

class HorizontalList extends StatefulWidget {
  HorizontalList({Key key, this.title: '豆瓣热门', this.state = 'hot'})
      : super(key: key);
  final String title;
  final String state;

  @override
  _HorizontalListState createState() => _HorizontalListState();
}

class _HorizontalListState extends State<HorizontalList> {
  @override
  void initState() {
    super.initState();
  }

  Future _getHotMovies() async {
    return await getHotMovies().then((data) {
      return data['rows'];
    });
  }

  Future _getComingMovies() async {
    Response response = await Dio().get('http://localhost:3000/movies/coming');
    return response.data['rows'];
  }

  Future _getMovies() async {
    if (widget.state == 'hot') {
      return _getHotMovies();
    } else if (widget.state == 'coming') {
      return _getComingMovies();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        children: <Widget>[
          Container(
            height: 105.w,
            color: Colors.white,
            padding: EdgeInsets.only(left: 30.w, right: 30.w),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                Text(
                  widget.title,
                  style:
                      TextStyle(fontWeight: FontWeight.w600, fontSize: 30.sp),
                ),
                InkWell(
                  onTap: () {
                    Application.router.navigateTo(context, '/list');
                  },
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      Text(
                        '查看更多',
                        style: TextStyle(
                            color: Color(0xFF41bd55), fontSize: 30.sp),
                      ),
                      Icon(
                        Icons.keyboard_arrow_right,
                        color: Color(0xFF41bd55),
                      )
                    ],
                  ),
                ),
              ],
            ),
          ),
          Container(
              height: 330.w,
              child: FutureBuilder(
                future: _getMovies(),
                builder:
                    (BuildContext context, AsyncSnapshot<dynamic> snapshot) {
                  if (snapshot.hasData) {
                    return ListView.builder(
                      scrollDirection: Axis.horizontal,
                      padding: EdgeInsets.fromLTRB(15.w, 0, 15.w, 0),
                      itemCount: snapshot.data.length,
                      itemBuilder: (context, index) {
                        return MovieItem(item: snapshot.data[index]);
                      },
                    );
                  } else {
                    return Text('加载中...');
                  }
                },
              )),
        ],
      ),
    );
  }
}
