import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'dart:async';

class DetailPage extends StatefulWidget {
  DetailPage({
    Key key,
    this.movieId: '',
    this.movieTitle: '',
  }) : super(key: key);
  final String movieTitle;
  final String movieId;

  @override
  _DetailPageState createState() => _DetailPageState();
}

class _DetailPageState extends State<DetailPage> {
  Future _getDetailById() async {
    Response response = await Dio().get(
      'http://localhost:3000/movies/detail',
      queryParameters: {'_id': widget.movieId},
    );
    // print(response.data is List);
    return response.data;
  }

  // 头部
  Widget _detailHeader(Map movie) {
    return Container(
      padding: EdgeInsets.only(top: 10.w, bottom: 40.w),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          // 图片
          Container(
            width: 200.w,
            height: 280.w,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(10.w),
              child: Image.network(movie['movieImg'], fit: BoxFit.fill),
            ),
          ),
          // 文字
          Container(
            width: 450.w,
            margin: EdgeInsets.only(left: 35.w),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  movie['title'],
                  style: TextStyle(
                    fontSize: 44.sp,
                    fontWeight: FontWeight.bold,
                  ),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
                Text(
                  'Avengers: Endgame(2019)',
                  style: TextStyle(fontSize: 32.sp, color: Colors.black38),
                ),
                Padding(
                  padding: EdgeInsets.only(top: 20.w),
                ),
                Text(
                  '动作 科幻 奇幻 / 美国 / 片长181分钟',
                  style: TextStyle(fontSize: 24.sp, color: Colors.black38),
                ),
                Padding(padding: EdgeInsets.only(top: 45.w)),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    Container(
                      width: 210.w,
                      height: 74.w,
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(10.w),
                        child: RaisedButton(
                          color: Colors.white,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              Icon(
                                Icons.thumb_up,
                                size: 20,
                                color: Colors.orange,
                              ),
                              Padding(padding: EdgeInsets.only(left: 10.w)),
                              Text('想看')
                            ],
                          ),
                          onPressed: () {},
                        ),
                      ),
                    ),
                    Container(
                      width: 210.w,
                      height: 74.w,
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(10.w),
                        child: RaisedButton(
                          color: Colors.white,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              Icon(
                                Icons.star_border,
                                size: 20,
                                color: Colors.orange,
                              ),
                              Padding(padding: EdgeInsets.only(left: 10.w)),
                              Text('想看')
                            ],
                          ),
                          onPressed: () {},
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    ScreenUtil.init(context, width: 750, height: 1334, allowFontScaling: true);
    return Scaffold(
      backgroundColor: Color(0xFFf4f3f8),
      appBar: AppBar(
        // 自定义返回按钮
        leading: Icon(
          Icons.arrow_back_ios,
          color: Colors.red,
        ),
        title: Text(
          widget.movieTitle,
        ),
        backgroundColor: Colors.white,
        elevation: 0,
      ),
      body: Stack(
        children: <Widget>[
          FutureBuilder(
            future: _getDetailById(),
            builder: (context, snapshot) {
              if (snapshot.hasData) {
                print(snapshot.data is List);
                return Container(
                  padding: EdgeInsets.all(30.w),
                  child: ListView(
                    children: <Widget>[
                      _detailHeader(snapshot.data.first),
                      _detailHeader(snapshot.data.first),
                      _detailHeader(snapshot.data.first),
                      _detailHeader(snapshot.data.first),
                      _detailHeader(snapshot.data.first),
                      _detailHeader(snapshot.data.first),
                      _detailHeader(snapshot.data.first),
                      _detailHeader(snapshot.data.first),
                    ],
                  ),
                );
              } else {
                return Text('加载中');
              }
            },
          ),
          Positioned(
            bottom: 0,
            left: 0,
            child: Container(
              width: 750.w,
              height: 120.w,
              child: RaisedButton(
                padding: EdgeInsets.only(bottom: 30.w),
                color: Color(0xff41bd55),
                child: Text(
                  '评论',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 32.sp,
                  ),
                ),
                onPressed: () {},
              ),
            ),
          ),
        ],
      ),
    );
  }
}
