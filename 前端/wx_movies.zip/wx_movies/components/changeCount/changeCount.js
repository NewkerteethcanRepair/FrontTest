// components/changeCount/changeCount.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {

  },

  /**
   * 组件的初始数据
   */
  data: {
    count: ''
  },

  /**
   * 组件的方法列表
   */
  methods: {
    myIncrement() {
      this.triggerEvent('increment');
    },
    inputCount(e) {
      this.setData({
        count: e.detail.value
      })
    },
    setCount() {
      this.triggerEvent('setCount', { count: this.data.count });
    }
  }
})
