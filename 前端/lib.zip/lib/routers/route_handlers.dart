import 'package:douban_app/pages/detail/detail_page.dart';
import 'package:flutter/material.dart';
import 'package:fluro/fluro.dart';

import 'package:douban_app/tab_bottom_page.dart';
import 'package:douban_app/pages/list/list_page.dart';
import 'package:douban_app/pages/login/login_page.dart';

Handler rootHandler = Handler(
  handlerFunc: (BuildContext context, Map<String, dynamic> params) {
    return TabBottomPage();
  },
);

Handler listHandler = Handler(
  handlerFunc: (BuildContext context, Map<String, dynamic> params) {
    return ListPage();
  },
);

Handler loginHandler = Handler(
  handlerFunc: (BuildContext context, Map<String, dynamic> params) {
    return LoginPage();
  },
);

Handler detailHandler = Handler(
  handlerFunc: (BuildContext context, Map<String, dynamic> params) {
    String movieId = params['movieId']?.first;
    String movieTitle = params['movieTitle']?.first;
    return DetailPage(movieId: movieId, movieTitle: movieTitle);
  },
);
