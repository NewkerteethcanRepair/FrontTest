
// export const ADDTO="addTodo";
export  const ADDTODOLIST= "addtolist";
export const DONETOGGLE="dongtoggle"
export const FILTER="filterdata"