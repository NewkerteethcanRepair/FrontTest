// components/mySwiper/mySwiper.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {

  },

  /**
   * 组件的初始数据
   */
  data: {
    swiperImages: [
      "https://liangcang-material.alicdn.com/prod/upload/47ad6ee153484a09b493c9d8bb9631fe.jpg?x-oss-process=image/resize,w_750/format,webp/interlace,1",
      "http://puui.qpic.cn/tv/0/813087686_1080607/0",
      "https://m.iqiyipic.com/common/lego/20200407/a45498f7a63547cbb47542cea3a1d6d2.jpg"
    ]
  },

  /**
   * 组件的方法列表
   */
  methods: {

  }
})
