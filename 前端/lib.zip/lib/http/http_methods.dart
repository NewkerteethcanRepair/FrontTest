import 'package:dio/dio.dart';
import 'package:douban_app/http/http_url.dart';

Future getHotMovies({start = 0, count = 8}) async {
  Response response = await Dio().get(
    httpPath['getHotMovies'],
    queryParameters: {
      'start': start,
      'count': count,
    },
  );
  return response.data;
}

