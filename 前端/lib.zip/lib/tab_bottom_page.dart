import 'package:douban_app/routers/application.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import 'package:douban_app/pages/home/home_page.dart';
import 'package:douban_app/pages/mine/mine_page.dart';
import 'package:douban_app/pages/top/top_page.dart';

class TabBottomPage extends StatefulWidget {
  TabBottomPage({Key key}) : super(key: key);

  @override
  _TabBottomPageState createState() => _TabBottomPageState();
}

class _TabBottomPageState extends State<TabBottomPage> {
  List<Widget> tabPages = [HomePage(), TopPage(), MinePage()];
  int currentIndex = 0;

  @override
  Widget build(BuildContext context) {
    ScreenUtil.init(context, width: 750, height: 1334, allowFontScaling: true);

    Widget userHeader = UserAccountsDrawerHeader(
      accountName: new Text('张三'),
      accountEmail: new Text('zhangsan@xxx.com'),
      currentAccountPicture: new CircleAvatar(
        backgroundImage: AssetImage('images/p1.jpg'),
        // radius: 35,
      ),
    );

    return Scaffold(
      // 底部导航栏
      bottomNavigationBar: BottomNavigationBar(
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.home), title: Text('首页')),
          BottomNavigationBarItem(
              icon: Icon(Icons.view_headline), title: Text('榜单')),
          BottomNavigationBarItem(
              icon: Icon(Icons.supervisor_account), title: Text('我的')),
        ],
        type: BottomNavigationBarType.fixed,
        currentIndex: currentIndex,
        onTap: (index) {
          setState(() {
            currentIndex = index;
          });
        },
      ),
      // 侧边抽屉
      endDrawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            userHeader, // 可在这里替换自定义的header
            ListTile(
              title: Text('Item 1'),
              subtitle: new Text('我是副标题'),
              leading: new CircleAvatar(
                backgroundColor: Color(0xFF41bd55),
                child: new Icon(Icons.school, color: Colors.white),
              ),
              onTap: () {
                Navigator.pop(context);
              },
            ),
            Divider(indent: 40.w, color: Colors.black12),
            ListTile(
              title: Text('登录'),
              leading: new CircleAvatar(
                backgroundColor: Color(0xFF41bd55),
                child: new Text('我', style: TextStyle(color: Colors.white)),
              ),
              onTap: () {
                Application.router.navigateTo(context, '/login');
              },
            ),
            Divider(indent: 40.w, color: Colors.black12),
            ListTile(
              title: Text('Item 3'),
              leading: CircleAvatar(
                backgroundColor: Color(0xFF41bd55),
                child: Icon(Icons.list, color: Colors.white),
              ),
              onTap: () {
                Navigator.pop(context);
              },
            ),
            Divider(indent: 40.w, color: Colors.black12),
            ExpansionTile(
              title: Text('可展开组件标题'),
              leading: Icon(Icons.ac_unit),
              children: <Widget>[
                ListTile(
                  title: Text('Item 3'),
                ),
                ListTile(
                  title: Text('Item 3'),
                ),
              ],
            )
          ],
        ),
      ),
      body: tabPages[currentIndex],
    );
  }
}
