export const GETSTUDENTDATA="getstudentdata"

