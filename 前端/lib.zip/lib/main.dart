import 'package:flutter/material.dart';
import 'package:fluro/fluro.dart';
import 'package:douban_app/routers/routes.dart';
import 'package:douban_app/routers/application.dart';

import 'package:douban_app/tab_bottom_page.dart';

void main() {
  final router = Router();
  Routes.configureRoutes(router);
  Application.router = router;
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      onGenerateRoute: Application.router.generator,
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primaryColor: Color(0xFF41bd55),
        // primaryColorBrightness: Brightness.dark,
      ),
      home: TabBottomPage(),
    );
  }
}
