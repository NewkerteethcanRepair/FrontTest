import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class TopPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    ScreenUtil.init(context, width: 750, height: 1334, allowFontScaling: true);
    return DefaultTabController(
      length: 4,
      child: Scaffold(
        appBar: AppBar(
          title: Text(
            "榜单",
            style: TextStyle(color: Colors.white),
          ),
          brightness: Brightness.dark,
          bottom: TabBar(
            labelColor: Colors.white,
            indicator: UnderlineTabIndicator(
              borderSide: BorderSide(color: Colors.green[200], width: 5.w),
            ),
            tabs: <Widget>[
              Tab(text: "热门"),
              Tab(text: "推荐"),
              Tab(text: "收藏"),
              Tab(text: "新增"),
            ],
          ),
        ),
        body: TabBarView(
          children: <Widget>[
            Center(child: Text("这是热门榜单")),
            Center(child: Text("这是推荐榜单")),
            Center(child: Text("这是收藏榜单")),
            Center(child: Text("这是新增榜单"))
          ],
        ),
      ),
    );
  }
}
