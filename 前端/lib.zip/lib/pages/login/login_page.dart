import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:douban_app/routers/application.dart';

class LoginPage extends StatelessWidget {
  // LoginPage({Key key}) : super(key: key);

  var _username = '';
  var _password = '';

  // 焦点
  FocusNode _focusNodeUsername = FocusNode();
  FocusNode _focusNodePassword = FocusNode();

  @override
  Widget build(BuildContext context) {
    ScreenUtil.init(context, width: 750, height: 1334, allowFontScaling: true);
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        title: Text('登录'),
        brightness: Brightness.light,
        backgroundColor: Colors.white,
      ),
      // 外层添加一个手势，用于点击空白部分，回收键盘
      body: GestureDetector(
        onTap: () {
          // 点击空白区域，回收键盘
          print("点击了空白区域");
          _focusNodeUsername.unfocus();
          _focusNodePassword.unfocus();
        },
        child: ListView(
          children: <Widget>[
            Container(
              padding: EdgeInsets.only(left: 40.w, right: 40.w, bottom: 90.w),
              color: Colors.white,
              child: Column(
                children: <Widget>[
                  Container(height: 150.h), // 占位用
                  Text(
                    '豆瓣账号密码登录',
                    style:
                        TextStyle(fontSize: 60.sp, fontWeight: FontWeight.bold),
                  ),
                  Container(
                    margin: EdgeInsets.only(
                      top: 98.w,
                      bottom: 40.w,
                    ),
                    decoration: BoxDecoration(
                      border: Border.all(width: 1.w, color: Colors.black12),
                      borderRadius: BorderRadius.circular(10.w),
                    ),
                    child: Column(
                      children: <Widget>[
                        Container(
                          decoration: BoxDecoration(
                            border: Border(
                              bottom:
                                  BorderSide(width: 1.w, color: Colors.black12),
                            ),
                          ),
                          child: TextField(
                            decoration: InputDecoration(
                              contentPadding: EdgeInsets.only(left: 20.w),
                              border: InputBorder.none,
                              hintText: '手机号/邮箱',
                            ),
                            focusNode: _focusNodeUsername,
                            onChanged: (String val) {
                              _username = val;
                            },
                          ),
                        ),
                        Container(
                          child: TextField(
                            decoration: InputDecoration(
                              contentPadding: EdgeInsets.only(left: 20.w),
                              border: InputBorder.none,
                              hintText: '密码',
                            ),
                            focusNode: _focusNodePassword,
                            onChanged: (String val) {
                              _password = val;
                            },
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    width: 670.w,
                    height: 90.w,
                    margin: EdgeInsets.only(bottom: 66.w),
                    // 按钮本身不能设置宽高，所以需要在外面套一个container
                    child: RaisedButton(
                      color: Color(0xFFa1deab),
                      onPressed: () async {
                        Response response = await Dio()
                            .post('http://localhost:3000/users/login', data: {
                          'username': _username,
                          'password': _password
                        });
                        if (response.data.length > 0) {
                          Application.router
                              .navigateTo(context, '/', replace: true);
                        } else {
                          // 如果登录失败则弹出弹窗
                          return showDialog(
                              context: context,
                              builder: (context) {
                                return AlertDialog(
                                  title: Text('提示'),
                                  content: Text('登录失败'),
                                );
                              });
                        }
                      },
                      child: Text(
                        '登录',
                        style: TextStyle(
                          fontSize: 32.sp,
                          color: Color(0xFFd9f2dd),
                        ),
                      ),
                    ),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      Text(
                        '短信验证登录/注册',
                        style: TextStyle(
                          fontSize: 30.sp,
                          color: Color(0xFF42bd56),
                        ),
                      ),
                      Text(
                        '海外手机密码登录',
                        style: TextStyle(
                          fontSize: 30.sp,
                          color: Color(0xFF42bd56),
                        ),
                      ),
                    ],
                  ),
                  Container(
                    height: 430.h,
                  ), // 占位用
                  Center(
                    child: Text(
                      '忘记密码？找回密码',
                      style: TextStyle(
                        color: Color(0xFF60739b),
                        fontSize: 26.sp,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
