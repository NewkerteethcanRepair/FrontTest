import 'package:douban_app/pages/home/home_swiper.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import 'package:douban_app/pages/home/horizontal_list.dart';

class HomePage extends StatelessWidget {
  Widget _getSearchBar() {
    return Container(
      padding: EdgeInsets.all(16.w),
      color: Color(0xFF41bd55),
      child: Container(
        height: 55.w,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(8.w),
          color: Colors.white,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Icon(
              Icons.search,
              color: Colors.black26,
              size: 30.w,
            ),
            Text(
              '搜索',
              style: TextStyle(
                color: Colors.black26,
              ),
            )
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    ScreenUtil.init(context, width: 750, height: 1334, allowFontScaling: true);
    return Scaffold(
      appBar: AppBar(
        title: Text(
          '首页',
          style: TextStyle(color: Colors.white),
        ),
        elevation: 0,
        brightness: Brightness.dark,
      ),
      body: ListView(
        children: <Widget>[
          _getSearchBar(),
          HomeSwiper(),
          HorizontalList(title: '影院热映', state: 'hot'),
          HorizontalList(title: '即将上映', state: 'coming'),
          HorizontalList(title: '豆瓣热门'),
          HorizontalList(title: '近期热门剧集'),
          HorizontalList(),
        ],
      ),
    );
  }
}

// class RowList extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return Column(
//       children: <Widget>[
//         Container(
//           height: 104.w,
//           color: Colors.red[100],
//         ),
//         Container(
//           height: 335.w,
//           child: ListView(
//             scrollDirection: Axis.horizontal,
//             padding: EdgeInsets.fromLTRB(15.w, 0, 15.w, 0),
//             children: <Widget>[
//               Container(
//                 width: 160.w,
//                 height: 305.w,
//                 color: Colors.blue[100],
//                 margin: EdgeInsets.only(left: 15.w, right: 15.w),
//                 alignment: Alignment.topCenter,
//                 child: ClipRRect(
//                   borderRadius: BorderRadius.circular(10.w),
//                   child: Image.asset('images/p1.jpg'),
//                 ),
//               ),
//               Container(
//                 width: 160.w,
//                 height: 305.w,
//                 color: Colors.blue[100],
//                 margin: EdgeInsets.only(left: 15.w, right: 15.w),
//               ),
//               Container(
//                 width: 160.w,
//                 height: 305.w,
//                 color: Colors.blue[100],
//                 margin: EdgeInsets.only(left: 15.w, right: 15.w),
//               ),
//               Container(
//                 width: 160.w,
//                 height: 305.w,
//                 color: Colors.blue[100],
//                 margin: EdgeInsets.only(left: 15.w, right: 15.w),
//               ),
//               Container(
//                 width: 160.w,
//                 height: 305.w,
//                 color: Colors.blue[100],
//                 margin: EdgeInsets.only(left: 15.w, right: 15.w),
//               ),
//               Container(
//                 width: 160.w,
//                 height: 305.w,
//                 color: Colors.blue[100],
//                 margin: EdgeInsets.only(left: 15.w, right: 15.w),
//               ),
//             ],
//           ),
//         ),
//       ],
//     );
//   }
// }
