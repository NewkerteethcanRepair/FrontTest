import {createAction} from "redux-actions";
import { ADDTO } from "./actions-type";
// import (ADDTO0)


export const addto=createAction(ADDTO);

