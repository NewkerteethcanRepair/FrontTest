const httpURL = 'http://localhost:3000';
const httpPath = {
  'getHotMovies': httpURL + '/movies/hot', // 请求热映电影
  'getComingMovies': httpURL + '/movies/coming', // 请求即将上映电影
  'searchMovies': httpURL + '/movies/search', // 搜索电影
  'getMoviesDetail': httpURL + '/movies/detail', // 获取电影详情
};
