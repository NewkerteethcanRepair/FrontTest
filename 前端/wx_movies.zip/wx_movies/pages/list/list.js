// pages/list/list.js
const { url } = getApp().globalData;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    start: 0,
    count: 15,
    total: 0,
    rows: []
  },

  getMovies() {
    wx.request({
      url: url + '/movies/hot',
      // methods: 'get',
      data: {
        start: this.data.start,
        count: this.data.count
      },
      success: ({ data }) => {
        this.setData({
          total: data.total,
          rows: [...this.data.rows, ...data.rows]
        }, () => {
          wx.hideLoading();
        })
      }
    });
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getMovies();
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    wx.showLoading({
      title: '刷新中...',
    });
    this.setData({
      start: 0,
      total: 0,
      rows: []
    }, () => {
      this.getMovies();
    })
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    if (this.data.rows.length < this.data.total) {
      wx.showLoading({
        title: '加载中...',
      });
      this.setData({
        start: this.data.start + this.data.count
      }, () => {
        this.getMovies();
      })
    }
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})