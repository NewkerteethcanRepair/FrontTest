// components/stars/stars.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    starsNumber: String
  },

  /**
   * 组件的初始数据
   */
  data: {
    starsArray: []
  },

  lifetimes: {
    attached: function() {
      // 在组件实例进入页面节点树时执行
      this.getStars();
    }
  },
  /**
   * 组件的方法列表
   */
  methods: {
    getStars() {
      const { starsNumber } = this.properties;
      for (let i = 0; i < starsNumber[0]; i++) {
        this.setData({
          starsArray: [...this.data.starsArray, 'on']
        })
      }
      if (starsNumber[1] === '5') {
        this.setData({
          starsArray: [...this.data.starsArray, 'half']
        })
      }
      for (let i = this.data.starsArray.length; i < 5; i++) {
        this.setData({
          starsArray: [...this.data.starsArray, 'off']
        })
      }
    }
  }
})
