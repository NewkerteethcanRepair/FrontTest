import 'package:douban_app/routers/application.dart';
import 'package:flutter/material.dart';

class MinePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          '我的',
          style: TextStyle(color: Colors.white),
        ),
        brightness: Brightness.dark,
      ),
      body: Center(
        child: RaisedButton(
          child: Text('登录'),
          onPressed: () {
            Application.router.navigateTo(context, '/login');
          },
        ),
      ),
    );
  }
}
