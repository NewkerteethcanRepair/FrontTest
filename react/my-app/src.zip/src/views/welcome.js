import React, { Component } from 'react'

export default class welcome extends Component {
    render() {
        return (
            <div>
                <h1>hello world dengxiang</h1>
            </div>
        )
    }
}
