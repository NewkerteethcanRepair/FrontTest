import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import 'package:flutter_easyrefresh/easy_refresh.dart';

import 'package:douban_app/widgets/movie_item.dart';

class ListPage extends StatefulWidget {
  ListPage({Key key, this.movieState = 'hot'}) : super(key: key);
  final String movieState;
  @override
  _ListPageState createState() => _ListPageState();
}

class _ListPageState extends State<ListPage> {
  int start = 0;
  int count = 12;
  int total = 0;
  List moviesData = [];
  EasyRefreshController _controller;

  @override
  void initState() {
    super.initState();
    _controller = EasyRefreshController();
  }

  void _getMovies() async {
    Response response = await Dio().get('http://localhost:3000/movies/hot',
        queryParameters: {'start': start, 'count': count});
    setState(() {
      total = response.data['total'];
      moviesData.addAll(response.data['rows']);
      start = start + count;
    });
    _controller.finishRefresh();
    _controller.finishLoad(noMore: moviesData.length >= total);
  }

  @override
  Widget build(BuildContext context) {
    ScreenUtil.init(context, width: 750, height: 1334, allowFontScaling: true);
    return Scaffold(
      appBar: AppBar(
        title: Text('列表'),
      ),
      body: Container(
        padding: EdgeInsets.all(40.w),
        alignment: Alignment.topCenter,
        child: EasyRefresh(
          enableControlFinishRefresh: true,
          enableControlFinishLoad: true,
          controller: _controller,
          // 设置列表自定义头部
          header: ClassicalHeader(
            refreshingText: '正在刷新...',
            refreshedText: '刷新完成',
            refreshReadyText: '开始刷新...',
            textColor: Color(0xFF41bd55),
            infoColor: Colors.grey[500],
          ),
          // 设置列表自定义底部
          footer: ClassicalFooter(
            noMoreText: '没有更多数据',
            loadingText: '正在加载中...',
            loadReadyText: '开始加载...',
            loadedText: '加载完成',
            textColor: Color(0xFF41bd55),
            infoColor: Colors.grey[500],
          ),
          // Material 风格的上拉底部下拉顶部样式
          // header: MaterialHeader(),
          // footer: MaterialFooter(),
          child: GridView.builder(
            // 创建一个在横轴上具有固定数量的网格块的布局。
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 3, // 每行显示的数量
              crossAxisSpacing: 40.w, // 上下外边距
              mainAxisSpacing: 40.w, // 左右外边距
              childAspectRatio: 0.6, // 子元素宽高比
            ),
            itemCount: moviesData.length,
            itemBuilder: (context, index) {
              return MovieItem(item: moviesData[index]);
            },
          ),
          onLoad: () async {
            _getMovies();
          },
          onRefresh: () async {
            setState(() {
              start = 0;
              moviesData = [];
            });
            _getMovies();
          },
        ),
      ),
    );
  }
}
