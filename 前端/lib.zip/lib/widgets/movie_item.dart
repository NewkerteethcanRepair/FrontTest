import 'package:douban_app/widgets/stars.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:douban_app/routers/application.dart';

class MovieItem extends StatelessWidget {
  MovieItem({Key key, this.item}) : super(key: key);
  final Map item;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        Application.router
            .navigateTo(context, '/detail/${item['_id']}/${item['title']}');
      },
      child: Container(
        width: 160.w,
        color: Colors.white,
        margin: EdgeInsets.fromLTRB(15.w, 0, 15.w, 30.w),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: <Widget>[
            SizedBox(
              height: 224.w,
              width: 160.w,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(8.w),
                child: Image.network(item['movieImg'], fit: BoxFit.fill),
              ),
            ),
            Text(
              item['title'],
              style: TextStyle(
                fontSize: 26.sp,
                fontWeight: FontWeight.w600,
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                Stars(stars: item['stars']),
                Text(
                  item['average'],
                  style: TextStyle(fontSize: 20.sp),
                )
              ],
            ),
          ],
        ),
      ),
    );
  }
}
