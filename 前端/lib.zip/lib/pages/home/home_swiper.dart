import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_swiper/flutter_swiper.dart';

class HomeSwiper extends StatelessWidget {
  List<String> _swiperList = [
    "https://aecpm.alicdn.com/simba/img/TB1CWf9KpXXXXbuXpXXSutbFXXX.jpg_q50.jpg",
    "https://img.alicdn.com/simba/img/TB1.5f9v5_1gK0jSZFqSuwpaXXa.jpg_q50.jpg",
    "https://gw.alicdn.com/imgextra/i3/13/O1CN01I4U9oK1Bxzk2aOSbV_!!13-0-lubanu.jpg",
    "https://gw.alicdn.com/imgextra/i1/4/O1CN015RWo7M1BtsAyDAqVw_!!4-0-lubanu.jpg"
  ];
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 300.w,
      child: Swiper(
        itemCount: _swiperList.length,
        itemBuilder: (context, index) {
          return Image.network(
            _swiperList[index],
            fit: BoxFit.fill,
          );
        },
        autoplay: true,
        pagination: SwiperPagination(),
      ),
    );
  }
}
