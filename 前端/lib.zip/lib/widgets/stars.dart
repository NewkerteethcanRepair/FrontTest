import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class Stars extends StatelessWidget {
  Stars({Key key, this.stars}) : super(key: key);
  final String stars;

  List _getStars() {
    List<Widget> starsList = [];
    for (int i = 0; i < int.parse(stars[0]); i++) {
      starsList.add(Icon(Icons.star, color: Colors.orange, size: 22.w));
    }
    if (stars[1] == '5') {
      starsList.add(Icon(Icons.star_half, color: Colors.orange, size: 22.w));
    }
    for (int i = starsList.length; i < 5; i++) {
      starsList.add(Icon(Icons.star_border, color: Colors.black38, size: 22.w));
    }
    return starsList;
  }

  @override
  Widget build(BuildContext context) {
    return Row(children: _getStars());
  }
}
