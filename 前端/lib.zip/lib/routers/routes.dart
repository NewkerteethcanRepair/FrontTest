import 'package:flutter/material.dart';
import 'package:fluro/fluro.dart';

import 'package:douban_app/pages/list/list_page.dart';
import 'package:douban_app/pages/login/login_page.dart';
import 'package:douban_app/tab_bottom_page.dart';
import './route_handlers.dart';

class Routes {
  static String root = '/';
  static String list = '/list';
  static String login = '/login';
  static String detail = '/detail/:movieId/:movieTitle';

  static void configureRoutes(Router router) {
    // 当匹配不到对应的路由时执行的操作
    router.notFoundHandler = Handler(
      handlerFunc: (BuildContext context, Map<String, List<String>> params) {
        print('这个路由迷路了找不到了～');
        return;
      },
    );

    router.define(root, handler: rootHandler);
    router.define(login, handler: loginHandler);
    router.define(list, handler: listHandler);
    router.define(detail, handler: detailHandler);
  }
}
